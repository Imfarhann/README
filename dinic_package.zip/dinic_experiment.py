"""
dinic_experiment.py
Simple script: implements Dinic, generates few graphs, runs experiments and writes CSV + runtime plot.
"""
import random, time, csv, math
from collections import deque

class Edge:
    def __init__(self,to,rev,cap):
        self.to=to; self.rev=rev; self.cap=cap

class Dinic:
    def __init__(self,n):
        self.n=n; self.g=[[] for _ in range(n)]; self.level=[0]*n; self.it=[0]*n
    def add_edge(self,u,v,c):
        self.g[u].append(Edge(v,len(self.g[v]),c))
        self.g[v].append(Edge(u,len(self.g[u])-1,0))
    def bfs(self,s,t):
        from collections import deque
        for i in range(self.n): self.level[i]=-1
        q=deque([s]); self.level[s]=0
        while q:
            u=q.popleft()
            for e in self.g[u]:
                if e.cap>0 and self.level[e.to]<0:
                    self.level[e.to]=self.level[u]+1; q.append(e.to)
        return self.level[t]>=0
    def dfs(self,u,t,f):
        if u==t: return f
        for i in range(self.it[u], len(self.g[u])):
            e=self.g[u][i]
            if e.cap>0 and self.level[e.to]==self.level[u]+1:
                ret=self.dfs(e.to,t,min(f,e.cap))
                if ret>0:
                    e.cap-=ret; self.g[e.to][e.rev].cap+=ret
                    return ret
            self.it[u]+=1
        return 0
    def max_flow(self,s,t):
        flow=0; INF=10**18
        while self.bfs(s,t):
            self.it=[0]*self.n
            while True:
                f=self.dfs(s,t,INF)
                if f==0: break
                flow+=f
        return flow

def generate_chain(n):
    edges=[]
    for i in range(n-1):
        edges.append((i,i+1, random.randint(1,100)))
    return edges

def build_and_run(n, edges, s, t):
    d=Dinic(n)
    for u,v,c in edges:
        d.add_edge(u,v,c)
    t0=time.perf_counter(); mf=d.max_flow(s,t); t1=time.perf_counter()
    return mf, (t1-t0)*1000.0

if __name__=='__main__':
    random.seed(42)
    rows=[]
    for n in [50,100]:
        for inst in range(3):
            edges=generate_chain(n)
            mf, ms = build_and_run(n, edges, 0, n-1)
            rows.append((n, mf, ms))
    with open('experiment_results.csv','w',newline='') as f:
        import csv
        w=csv.writer(f); w.writerow(['n','mf','ms'])
        w.writerows(rows)
    print('Done')
