# Dinic Experiment (example repository)

This repository contains the implementation and experiment scripts used in the paper:
"Implementasi dan Analisis Algoritma Dinic untuk Model Alokasi Bandwidth pada Jaringan Sederhana".

## Structure
- `dinic_experiment.py` : main script that generates graphs, runs Dinic and Edmonds-Karp, and outputs CSV + plots.
- `makalah_dinic.docx` : draft paper (Sections I-III) with figures.
- `data/experiment_results.csv` : sample results (CSV) produced by the script.
- `figures/` : contains `topologies_v2.png`, `residual_flow.png`, `level_blocking.png`, `runtime_plot.png`.
- `README_dinic_experiment.md` : this file (overview + how to run).

## How to run (example)
1. Install Python 3.8+ and required packages:
   ```bash
   pip install networkx matplotlib python-docx
   ```
2. Run the experiment script:
   ```bash
   python dinic_experiment.py
   ```
3. Output files will be created in the working directory: `experiment_results.csv`, `runtime_plot.png`

## Reproducibility
- The script sets a fixed random seed by default. To reproduce multiple instances, change the seed or add `--seed` option in the script.
- For archival, consider creating a GitHub release and archiving it on Zenodo to obtain a DOI for citation.

## License
Add your preferred license (e.g., MIT) if you intend to publish the repository.
